WILLIAMS PORTFOLIO WEBSITE

1. Keep index.html and the assets folder together.
2. Open index.html in a browser to preview the website.
3. Your uploaded owner photo is already included as assets/williams-owner.png.
4. Add 10 project screenshots to the assets folder using these exact names:
   project-01.jpg, project-02.jpg, ... project-10.jpg
   The cards will show numbered orange placeholders until you add screenshots.
5. Open index.html and find the CONTACT settings near the bottom of the file.
   Add your WhatsApp number (international format, no + or spaces), email, and Instagram URL.
6. Replace each project's description and link with your real project details before publishing.

The contact form uses the visitor's email app (mailto). For a form that sends messages directly
without opening an email app, connect a form service or backend.
